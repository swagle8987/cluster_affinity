class Counter(object):

    """Docstring for Counter. """

    def __init__(self):
        self.count = 0

    def get_count(self):
        return self.count

    def count_up(self):
        self.count += 1
        
